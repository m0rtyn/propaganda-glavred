# propaganda-gravred

Extension for highlight bullshit patterns of earnings manipulation and political propaganda

# Usage

1. Enter the extensions developer mode in your browser and add your repo folder. It will show up near other installed extensions and will be ready to run
2. (optional) Publish your extension to browser extensions stores